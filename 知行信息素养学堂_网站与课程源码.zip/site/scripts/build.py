"""从已保存的知识库快照与原创教学练习生成静态课程；不修改原知识库。"""
from pathlib import Path
import json, re, hashlib

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist'
def read(name):
    return json.loads((ROOT / 'content' / name).read_text())
sources = read('sources.json')
source_ids = {s['id'] for s in sources}
specs = [
 ('看懂信息环境','辨认信息怎样产生、传播和影响判断','信息素养与终身学习|数据-信息-知识|信息生态|信息生产者|信息中介|信息生命周期|信息过载','ala1989|cilip2018|unesco2021'),
 ('把需求变成好问题','提出有边界、能检索、能回答的问题','信息需要|知识缺口|问题边界|研究问题形成|问题拆解法|信息类型与任务匹配|检索终止条件','sconul2011|acrl2016'),
 ('找到真正需要的资料','选择来源、构造检索、记录调整','信息源|关键词|受控主题词|布尔逻辑与字段检索|概念组检索式设计|策略性检索|查全率与查准率|引文追踪|滚雪球检索|政府开放数据检索','sconul2011|acrl2016|digcomp2025'),
 ('判断信息与证据','追溯出处、识别误导、保留不确定性','来源|证据|情境化权威|可信度|偏见|不确定性|相关与因果|同行评议、预印本与更正|主张证据推理链|主张拆解核查|横向阅读|三问横向核查|多源三角互证|图像与视频溯源|政府开放数据质量评价','acrl2016|cilip2018|cor'),
 ('整理为自己的知识','保留出处，比较材料，形成新理解','原子化笔记|分类-标签与主题词|文献矩阵|信息综合|知识创新|元数据、版本与备份','sconul2011|acrl2016|digcomp2025'),
 ('清楚表达，负责分享','让观点可追溯，让表达对受众有用','受众意识|论证|学术对话|引用|多模态表达|更正与负责任分享','acrl2016|cilip2018|digcomp2025'),
 ('守住权利、安全与公平','合理使用信息，保护自己与他人','信息具有价值|知识产权|著作权|学术诚信|隐私|信息公平|账号安全与钓鱼识别','cilip2018|digcomp2025|cc|copyright|privacy'),
 ('面对媒体、数据与AI','理解平台影响，学会有判断地协作','媒体素养|错误信息-虚假信息与恶意信息|预先辟谣|数据素养|政府开放数据|算法素养|AI素养|AI协作提示与过程记录|AI回答核查|AI引用逐条核验','unesco2021|unesco2024|digcomp2025')
]
practices = {}
for name in ['practice.tsv','supplement-practice.tsv']:
    for line in (ROOT/'content'/name).read_text().splitlines():
        row = line.split('\t')
        assert len(row)==9, row[0]
        key,explain,q,opts,answer,feedback,task,sample,criteria=row
        assert key not in practices, key
        practices[key] = dict(explain=explain,question=q,options=opts.split('~'),answer=int(answer),feedback=feedback,task=task,sample=sample,criteria=criteria.split('~'))
notes = {n['key']:n for n in read('vault-snapshot.json')}
supp = {n['title']:n for n in read('supplements.json')}
allkeys = [k for spec in specs for k in spec[2].split('|')]
assert len(allkeys)==len(set(allkeys))==68
assert set(allkeys)==set(practices)==set(notes)|set(supp)
ids={k:f'm{mi+1}-{i+1:02}' for mi,s in enumerate(specs) for i,k in enumerate(s[2].split('|'))}
framework_names={'ALA1989':'ala1989','ACRL2000':'acrl2000','SCONUL2011':'sconul2011','ACRL2016':'acrl2016','CILIP2018':'cilip2018','UNESCO2021':'unesco2021'}
def wiki(match):
    value=match.group(1).split('|')
    key=value[0].replace('ILKB-','')
    label=value[-1].replace('ILKB-','')
    if key in ids:return f'[{label}](#lesson/{ids[key]})'
    for prefix,fid in framework_names.items():
        if prefix in key:return f'[{label}](#sources/{fid})'
    return label
def cleaned(text):
    text=re.sub(r'^# .*\n','',text,count=1)
    # 源卡的教学活动由逐项新写的公众练习替代；框架和来源另在每课展示。
    chunks=re.split(r'(?=^## )',text,flags=re.M)
    text='\n'.join(c for c in chunks if not re.match(r'## (?:(?:8|9|10)\. |来源|相关知识|依据)',c))
    text=re.sub(r'^## \d+\. ', '### ',text,flags=re.M)
    text=re.sub(r'^## ', '### ',text,flags=re.M)
    text=re.sub(r'\[\[(.*?)\]\]',wiki,text)
    return text.strip()
lessons=[];modules=[]
for mi,(title,desc,keys,refs) in enumerate(specs,1):
    module=dict(id=mi,title=title,description=desc,refs=refs.split('|'),lessons=[])
    for key in keys.split('|'):
        source=notes.get(key); addition=supp.get(key)
        body=cleaned(source['body']) if source else addition['body']
        p=practices[key]
        sourceRefs=[]
        if source:
            for name,fid in framework_names.items():
                if name in source['body']:sourceRefs.append(fid)
        refsForLesson=list(dict.fromkeys((addition['refs'] if addition else sourceRefs or module['refs'][:2])))
        if key in ['横向阅读','三问横向核查','图像与视频溯源']:refsForLesson=['cor']
        if key=='著作权':refsForLesson+=['cc','copyright']
        if key=='隐私':refsForLesson+=['privacy']
        lesson=dict(id=ids[key],module=mi,title=key.replace('数据-信息-知识','数据、信息与知识').replace('分类-标签与主题词','分类、标签与主题词').replace('错误信息-虚假信息与恶意信息','错误信息、虚假信息与恶意信息'),key=key,body=body,refs=refsForLesson,source=source['path'] if source else '课程补充编写',minutes=20,**p)
        lessons.append(lesson);module['lessons'].append(lesson['id'])
    modules.append(module)
data=dict(title='知行 · 信息素养学堂',date='2026-09-29',audience='社会各行各业的成人学习者',modules=modules,lessons=lessons,sources=sources,projects=read('projects.json'))
OUT.mkdir(exist_ok=True)
(OUT/'course-data.js').write_text('window.COURSE = '+json.dumps(data,ensure_ascii=False)+';\n')
md=['# 知行 · 信息素养学堂\n\n面向社会各行各业成人学习者。8个模块，68个知识点，每点含讲解、判断题、实作和参考反馈。建议每课约20分钟；全课约23小时，综合项目另需2—3小时。时长为教学建议，并非学习效果承诺。\n\n来源核查日期：2026-09-29。60项来自Obsidian知识库，8项补充编写。案例数字均为模拟。框架映射为课程编写者的教学解释，不构成官方认证。\n\n每项实作按3个标准自评，每项0分（未体现）、1分（部分体现）、2分（充分且有证据），共6分。答对判断题不等于已具备实际能力。']
mapping=['# 知识点覆盖与来源映射\n\n核查日期：2026-09-29。来源范围：Obsidian-Xing / card / 3 信息素养知识库-2026 的01—08领域中全部60个非MOC概念/方法文件；另外8个知识点为课程补充。没有声称穷尽其他案例库、图卡或所有年份的指南。原始笔记未修改。\n\n|知识点|模块|知识库路径|框架参照|\n|---|---|---|---|']
for m in modules:
    md.append(f"\n## {m['id']:02} {m['title']}\n\n{m['description']}\n")
    for l in [x for x in lessons if x['module']==m['id']]:
        md.append(f"\n### {l['title']}\n\n学习目标：{'；'.join(l['criteria'])}。\n\n{l['explain']}\n\n{l['body']}\n\n#### 判断练习\n\n{l['question']}\n\n"+'\n'.join(f'{i+1}. {o}' for i,o in enumerate(l['options']))+f"\n\n答案：{l['answer']+1}。{l['feedback']}\n\n#### 实作练习\n\n{l['task']}\n\n参考思路：{l['sample']}\n\n评价标准：{'；'.join(l['criteria'])}。\n\n来源：{l['source']}。框架对应：{', '.join(l['refs'])}。\n")
        mapping.append(f"|{l['title']}|{m['id']}|{l['source']}|{', '.join(l['refs'])}|")
for p in data['projects']:
    md.append(f"\n## 综合项目：{p['title']}\n\n{p['brief']}\n")
    md.extend(f"### {x['title']}\n\n{x['text']}\n" for x in p['materials'])
    md.append('### 提交要求\n\n'+'\n'.join('- '+x for x in p['deliverables'])+'\n\n### 参考分析\n\n'+p['answer'])
md.append('\n## 权威文件与补充资源\n')
md.extend(f"- {s['id']}：{s['org']}（{s['year']}）。[{s['title']}]({s['url']})。{s['status']}。定位：{s['location']}。{s['summary']}" for s in sources)
(OUT/'完整课程讲义.md').write_text(re.sub(r'\[([^\]]+)\]\(#(?:lesson|sources)/[^)]+\)', r'\1', '\n'.join(md)))
(ROOT/'docs'/'知识点覆盖与来源映射.md').write_text('\n'.join(mapping))
(OUT/'来源与覆盖说明.md').write_text('\n'.join(mapping)+'\n\n## 权威文件\n\n'+'\n'.join(f"- {s['id']} [{s['title']}]({s['url']})（{s['year']}）：{s['status']}" for s in sources))
report=dict(lessons=len(lessons),vault_notes=len(notes),supplements=len(supp),quizzes=len(lessons),practice_tasks=len(lessons),projects=len(data['projects']),frameworks=10,additional_sources=4)
for l in lessons:
    assert len(l['body'])>140 and len(l['explain'])>20,l['key']
    assert len(l['criteria'])==3 and len(l['options'])==3
    assert 0<=l['answer']<3 and set(l['refs'])<=source_ids
    assert '[[' not in l['body']
(ROOT/'docs'/'content-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
